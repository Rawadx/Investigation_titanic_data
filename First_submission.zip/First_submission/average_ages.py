import pandas as pd

csv = pd.read_csv('titanic_data.csv') 

# getting average age of passengers after dropping unprovided fields
average_age = round(csv['Age'].dropna().mean(), 2)

#getting age data
age = csv['Age']

# getting average age of survivors after dropping unprovided fields
average_age_of_survivors = round(age[csv.Survived ==1].dropna().mean(), 2)  

print "Average age of Passangers is {0}".format(average_age)
print "Average age of survivors is {0}".format(average_age_of_survivors)
