from __future__ import division
import pandas as pd
from numpy import *

csv = pd.read_csv('titanic_data.csv')

# creating a numpy array of age column
np_age = csv['Age'].values 
# assigning empty fields to 0
nans= isnan(np_age)  
np_age[nans] =  0
# creating a numpy array of survived column
np_survived = csv['Survived'].values

# getting # of survivors from each age group
age_group_0 = np_survived[np_age == 0].sum()
age_group_1 =  np_survived[(np_age >0) & (np_age <=20)].sum()
age_group_2 = np_survived[(np_age >20) & (np_age <=40)].sum()
age_group_3 = np_survived[(np_age >40) & (np_age <=60)].sum()
age_group_4 = np_survived[(np_age >60) & (np_age <=80)].sum()

# Calculating the survivorship rate by age group 
group_1_survival_rate= round(age_group_1/len(np_survived[(np_age > 0) & (np_age <= 20)]), 4)*100
group_2_survival_rate= round(age_group_2/len(np_survived[(np_age >20) & (np_age <=40)]), 4)*100
group_3_survival_rate= round(age_group_3/len(np_survived[(np_age >40) & (np_age <=60)]), 4)*100
group_4_survival_rate= round(age_group_4/len(np_survived[(np_age >60) & (np_age <=80)]), 4)*100

# plotting the results in a bar chart 
import matplotlib.pyplot as plt

age_groups = {1:('0-20','r'), 
              2:('21-40','g'), 
              3:('41-60','b'),
              4:('61-80','k'),
             }
ax1 = plt.subplot(111)

xval = [1., 2., 3., 4.]
yval = [group_1_survival_rate, group_2_survival_rate,
        group_3_survival_rate, group_4_survival_rate]

for j in range(len(xval)):
    ax1.bar(xval[j], yval[j], width=0.8, bottom=0.0, align='center',
            color=age_groups[xval[j]][1], alpha=0.6,label=age_groups[xval[j]][0])
ax1.set_xticks(xval)
ax1.set_xticklabels([age_groups[i][0] for i in xval])
ax1.legend()
plt.show()
