import pandas as pd
from  numpy import *

csv = pd.read_csv('titanic_data.csv')


np_age = csv['Age'].values #creating a numpy array of the column Age
nans= isnan(np_age)
np_age[nans] =  0
np_name = csv['Name'].values 


# a function that returns the name of the oldest passanger 
def max_age(np_age, np_name):
    i = np_age.argmax()
    return (np_age[i], np_name[i])
    
print max_age(np_age, np_name)


 

