import pandas as pd

csv = pd.read_csv('titanic_data.csv')

name = csv['Name']
survived = csv['Survived']
age = csv['Age']

max_age = age.max() # getting max age among all passengers 
max_age_loc = age.argmax() # getting the location of max age
oldest_name = name[max_age_loc] # getting the name of the oldest passenger

survivor_ages = age[csv.Survived ==1]
oldest_survivor_age= survivor_ages.max() # getting the max age among survivors
oldsr_loc= survivor_ages.argmax() #getting the location of max age among survivors
oldest_survivor_name = name[oldsr_loc] #getting the name of the oldest survivor


print "The oldest passanger onboard is {0} of {1} years".format(oldest_name, max_age)
print "The oldest surviving passanger is {0} of {1} years".format(oldest_survivor_name,
                                                                  oldest_survivor_age)




