import pandas as pd

csv = pd.read_csv('titanic_data.csv')

survived = csv['Survived']

first_class = survived[(csv.Survived ==0) & (csv.Pclass ==1)].count()
second_class = survived[(csv.Survived ==0) & (csv.Pclass ==2)].count()
third_class = survived[(csv.Survived ==0) & (csv.Pclass ==3)].count()

print first_class
print second_class
print third_class

import matplotlib.pyplot as plt

data = [first_class, second_class, third_class]

plt.bar(range(len(data)), data)
plt.show()
