from __future__ import division
import pandas as pd

csv = pd.read_csv('titanic_data.csv')

survived = csv['Survived']
embarked = csv['Embarked']

# getting number of survivors from each port of embarkation
embarked_s = survived[(csv.Survived ==1) & (csv.Embarked =='S')].sum()
embarked_c = survived[(csv.Survived ==1) & (csv.Embarked =='C')].sum()
embarked_q = survived[(csv.Survived ==1) & (csv.Embarked =='Q')].sum()

# Calculating the survivorship rate by port of embarkation
s_rate = round(embarked_s/len(csv[csv.Embarked =='S']), 4)*100
c_rate = round(embarked_c/len(csv[csv.Embarked =='C']), 4)*100
q_rate = round(embarked_q/len(csv[csv.Embarked =='Q']), 4)*100


# plotting the results in a bar chart 
import matplotlib.pyplot as plt

ports = {1:('Port S','r'), 
              2:('Port C','g'), 
              3:('Port Q','b'), 
             }
ax1 = plt.subplot(111)

xval = [1., 2., 3.]
yval = [s_rate, c_rate, q_rate]

for j in range(len(xval)):
    ax1.bar(xval[j], yval[j], width=0.8, bottom=0.0, align='center',
            color=ports[xval[j]][1], alpha=0.6,label=ports[xval[j]][0])
ax1.set_xticks(xval)
ax1.set_xticklabels([ports[i][0] for i in xval])
ax1.legend()
plt.show()


