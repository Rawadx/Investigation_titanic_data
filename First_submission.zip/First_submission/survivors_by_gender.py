from __future__ import division
import pandas as pd

csv = pd.read_csv('titanic_data.csv')

survived = csv['Survived']
male_survivors = survived[csv.Sex=='male'].sum() #getting male survivors
female_survivors= survived[csv.Sex =='female'].sum() #getting female survivors


print ('Male survivors constitute {0}%'
        ' of the survivors while females' 
          ' constitue {1}%').format(round(male_survivors/csv['Survived'].sum(), 2)*100
                            , round(female_survivors/csv['Survived'].sum(), 2)*100)


# plotting the results in a pie chart
import matplotlib.pyplot as plt

# make the pie circular by setting the aspect ratio to 1
plt.figure(figsize=plt.figaspect(1))
data = [male_survivors, female_survivors]
labels = ['Male', 'Female']

def make_autopct(data):
    def my_autopct(pct):
        total = sum(data)
        val = int(round(pct*total/100.0))
        return '{p:.2f}%  ({v:d})'.format(p=pct,v=val)
    return my_autopct

plt.pie(data, labels=labels,autopct=make_autopct(data))
plt.show()
