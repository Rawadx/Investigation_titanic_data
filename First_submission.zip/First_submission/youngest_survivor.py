import pandas as pd

csv = pd.read_csv('titanic_data.csv')

name = csv['Name']
survived = csv['Survived']
age = csv['Age']

min_age = age.min() # getting min age among all passengers
min_age_loc = age.argmin() # getting the location of min age
youngest_name = name[min_age_loc] # getting the name of the youngest passenger

survivor_ages = age[csv.Survived ==1] # getting the min age among survivors
youngest_survivor_age= survivor_ages.min() #getting the location of min age among survivors
yngst_loc= survivor_ages.argmin() #getting the location of min age among survivors
youngest_survivor_name = name[yngst_loc] #getting the name of the youngest survivor


print "The youngest passanger onboard is {0} of {1} years".format(youngest_name, min_age)
print "The youngest surviving passanger is {0} of {1} years".format(youngest_survivor_name,
                                                                    youngest_survivor_age)




